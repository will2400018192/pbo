package com.kasir.uml;

public abstract class Pembayaran {
    public abstract String process(Transaksi trx);
}
