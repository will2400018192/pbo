package com.kasir;

import com.kasir.controller.KasirController;

public class KasirApplication {
    public static void main(String[] args) {
        KasirController.showGui();
    }
}
